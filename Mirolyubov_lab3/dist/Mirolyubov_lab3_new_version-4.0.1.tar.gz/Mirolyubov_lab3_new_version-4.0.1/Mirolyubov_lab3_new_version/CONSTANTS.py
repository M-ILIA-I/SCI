PRIMITIVE_TYPES = (int, str, bool, float, type(None))
