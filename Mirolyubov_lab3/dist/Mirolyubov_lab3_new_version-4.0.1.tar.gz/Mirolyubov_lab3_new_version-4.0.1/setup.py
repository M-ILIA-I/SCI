from setuptools import setup, find_packages


setup(
    name="Mirolyubov_lab3_new_version",
    version="4.0.1",
    description="Library for serialization JSON, XML",
    author="Mirolyubov Ilya",
    author_email="ilyamir1@mail.ru",
    packages=["Mirolyubov_lab3_new_version"],
    include_package_data=True,
)
